create definer = root@localhost trigger FormatISBN
    before insert
    on books
    for each row
BEGIN
  DECLARE formattedISBN VARCHAR(45);
  
  SET formattedISBN = CONCAT('-',NEW.isbn);
  SET NEW.isbn = formattedISBN;
END;

